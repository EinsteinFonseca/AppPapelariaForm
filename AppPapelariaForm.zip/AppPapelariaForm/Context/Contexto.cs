﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AppPapelariaForm;

namespace AppPapelariaForm
{
    internal class Contexto
    {
        public static List<Produto> ListaProdutos = new List<Produto>();
    }
}
