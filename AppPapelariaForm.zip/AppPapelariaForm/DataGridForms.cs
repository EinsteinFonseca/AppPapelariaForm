﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.Remoting.Contexts;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using AppPapelariaForm;

namespace AppPapelariaForm
{
    public partial class DataGridForms : Form
    {
        List <Produto> ListaProdutos = new List <Produto> ();
        public DataGridForms()
        {
            InitializeComponent();
            ListaProdutos = Contexto.ListaProdutos;

            var ProdutoSelec = ListaProdutos.OrderBy(m => m.Nome).ToList();
            dtConsultar.DataSource = ProdutoSelec.ToList();

        }

        private void DataGridForms_Load(object sender, EventArgs e)
        {

        }

        private void dtConsultar_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
    }
}
