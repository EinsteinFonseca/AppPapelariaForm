﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.Remoting.Contexts;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppPapelariaForm
{
    public partial class ConsultarForm : Form
    {
        public static List<Produto> ListaProdutos = new List<Produto>();
        int cont = 1;
        public ConsultarForm()
        {
            InitializeComponent();

            ListaProdutos = Contexto.ListaProdutos.ToList();

            cbConsultar.DataSource = ListaProdutos.ToList();

           
            cbConsultar.DisplayMember = "Nome";
            cbConsultar.SelectedIndex = -1;
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void cmbConsultar_SelectedIndexChanged(object sender, EventArgs e)
        {
            int linhaSelec = cbConsultar.SelectedIndex;
            if (linhaSelec > -1 && cont > 1)
            {
                var produtos = ListaProdutos [linhaSelec];
              
               txtNome.Text  = produtos.Nome;
               txtPreco.Text = produtos.Preco.ToString();
               txtQuantidade.Text = produtos.Quantidade.ToString();
               txtCategoria.Text = produtos.Categoria.ToString();
                
            }
            cont++;
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
