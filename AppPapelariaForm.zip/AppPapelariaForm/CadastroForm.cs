﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.Remoting.Contexts;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using AppPapelariaForm;

namespace AppPapelariaForm
{
    public partial class CadastroForm : Form
    {
        public static int Id = 1;
        public CadastroForm()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void CadastroForm_Load(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
          
        }

        private void txtPreco_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void txtQuantidade_TextChanged(object sender, EventArgs e)
        {
           
        }

        private void txtCategoria_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void btAdicionar_Click(object sender, EventArgs e)
        {
            Produto item = new Produto();

            item.Quantidade = Convert.ToInt32(txtQuantidade.Text);
            item.Categoria = Convert.ToString(txtCategoria.Text);
            item.Preco = Convert.ToDecimal(txtPreco.Text);
            item.Nome = Convert.ToString(txtNome.Text);
            item.Id = Id;
            Id++;
            Contexto.ListaProdutos.Add(item);

            MessageBox.Show("SALVO COM SUCESSO!   b(￣▽￣)d ", "EINSTEIN FONSECA  - 2A/INF", MessageBoxButtons.OK, MessageBoxIcon.Information);
            txtNome.Clear(); txtPreco.Clear(); txtQuantidade.Clear();
            txtCategoria.Clear();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
